#!/bin/bash
############ Initiate Docker Swarm ############
docker swarm init

# For Creating Overlay Networks for Traefik and Socket Proxy
docker network create --driver=overlay traefik_webgateway
docker network create --driver=overlay socket_network

# For MariaDB
echo 'SET_YOUR_DB_PASSWORD_HERE' | docker secret create mariadb_root_password -

# # AWS & Digital Ocean Secrets for MSMTP
echo 'ENTER_YOUR_SENDGRID_KEY_HERE' | docker secret create msmtp_sendgrid -
