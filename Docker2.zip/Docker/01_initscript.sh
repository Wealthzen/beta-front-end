
#!/bin/bash
# Install Docker
curl -fsSL get.docker.com -o get-docker.sh
# sh get-docker.shAdd user ubuntu to the docker group
sudo usermod -aG docker ubuntu

# Add Aliases and functions to bashrc
DOCKERPATH="$HOME/Docker"
 cat >> $HOME/.bashrc << EOF

######################################## ALIASES ########################################

alias dockdir="cd $DOCKERPATH"
alias webroot="cd $DOCKERPATH/mydevstack/webroot"

alias dockerup="docker stack deploy -c $DOCKERPATH/adminstack/adminstack.yml traefik;docker stack deploy -c $DOCKERPATH/mydevstack/mydevstack.yml mydevstack"
alias dockerdown="docker stack rm traefik; docker stack rm mydevstack; docker stack rm guistack;"

function dcntshell(){
  cntid=\$(docker container ls -f name="\$1" -q)
  docker container exec -it \$cntid /bin/bash
}

function dcntshalp(){
  cntid=\$(docker container ls -f name="\$1" -q)
  docker container exec -it \$cntid /bin/sh
}

function dcntid(){
  # docker container ls -f name="\$1" -q

    if [ "\$1" != "" ] # or better, if [ -n "\$1" ]
    then
        docker container ls -f name="\$1" -q
    else
    echo "Name of container not specified"
        docker container ls
    fi
}
EOF

source ~/.bashrc
